import slider from './components/slider'
export default slider
